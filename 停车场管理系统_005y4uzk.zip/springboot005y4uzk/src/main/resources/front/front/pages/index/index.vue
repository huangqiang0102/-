<template>
<view class="content">
	<view :style='{"minHeight":"100vh","padding":"120rpx 0 0 0","background":"#f5eeee","flexDirection":"column","display":"flex","width":"100%","position":"relative","height":"auto"}'>
		<swiper :style='{"width":"100%","padding":"40rpx 60rpx 0","borderRadius":"0 0 40rpx 40rpx","background":"linear-gradient(180deg, #FBE5E6 0%, #E6CFF4 100%)","height":"360rpx"}' class="swiper" :indicator-dots='true' :autoplay='true' :circular='true' indicator-active-color='#000000' indicator-color='rgba(0, 0, 0, .3)' :duration='500' :interval='5000' :vertical='false'>
			<swiper-item :style='{"width":"90%","margin":"0 auto","borderRadius":"0 0 40rpx 40rpx","height":"300rpx"}' v-for="(swiper,index) in swiperList" :key="index" @tap="onSwiperTap(swiper)">
				<image :style='{"width":"100%","objectFit":"cover","display":"block","height":"300rpx"}' mode="aspectFill" :src="baseUrl+swiper.img"></image>
				<view v-if="false" :style='{"width":"100%","padding":"0 8rpx","lineHeight":"60rpx","fontSize":"28rpx","color":"#333","background":"#fff"}'>{{ swiper.title }}</view>
			</swiper-item>
		</swiper>
		<!-- menu -->
		<view v-if="true" class="menu" :style='{"padding":"10rpx","margin":"40rpx 20rpx","backgroundColor":"#f5efef","flexWrap":"wrap","backgroundImage":"url(http://codegen.caihongy.cn/20231226/947ecbb6f548496c8aef90047faf427e.png)","display":"flex","width":"auto","backgroundSize":"100% 100%","height":"auto"}'>
            <block v-for="(item,index1) in menuList" v-bind:key="item.roleName">
                <block v-if="index1==0" v-bind:key="index" v-for=" (menu,index) in item.frontMenu">
                    <block v-bind:key="sort" v-for=" (child,sort) in menu.child">
                        <block v-bind:key="sort2" v-for=" (button,sort2) in child.buttons">
                            <view :style='{"width":"23%","padding":"12rpx","margin":"10rpx 1%","backgroundSize":"100% 100%","backgroundImage":"url(http://codegen.caihongy.cn/20231226/d401199a45a1433e8eb02fcaa12a729f.png)","height":"auto"}' class="menu-list" v-if="button=='查看' && child.tableName!='yifahuodingdan' && child.tableName!='yituikuandingdan' &&child.tableName!='yiquxiaodingdan' && child.tableName!='weizhifudingdan' && child.tableName!='yizhifudingdan' && child.tableName!='yiwanchengdingdan' " @tap="onPageTap2('../'+child.tableName+'/list')">
                                <view class="iconarr" :class="child.appFrontIcon" :style='{"padding":"0","margin":"6rpx auto","color":"#333","borderRadius":"100%","display":"block","width":"60rpx","lineHeight":"60rpx","fontSize":"60rpx","height":"60rpx"}'></view>
                                <view :style='{"padding":"0","margin":"12rpx auto","color":"#333","textAlign":"center","width":"100%","lineHeight":"28rpx","fontSize":"24rpx"}'>{{child.menu.split("列表")[0]}}</view>
                            </view>
                        </block>
                    </block>
                </block>
            </block>
		</view>
		<!-- menu -->
		<!-- 商品推荐 -->
		<view class="listBox recommend" :style='{"padding":"40rpx 0px","margin":"0","background":"#f5efef","order":"3"}'>
			<view class="title" :style='{"padding":"0 24rpx","margin":"0","backgroundImage":"url(http://codegen.caihongy.cn/20231226/09d62b9aee0742c8819dd6c606b5f63c.png)","width":"100%","backgroundSize":"100% 100%","position":"relative","height":"200rpx"}'>
				<view :style='{"color":"#E34E4E","top":"30rpx","left":"0","textAlign":"center","width":"200rpx","fontSize":"28rpx","lineHeight":"80rpx","position":"relative"}'>车位信息推荐</view>
			</view>
			<view id="recommend-list-10" class="recommend-box10 waterfall-body" :style='{"width":"100%","padding":"20rpx 24rpx 0","alignItems":"flex-start","display":"flex","height":"auto"}'>
				<view id="waterfall-left-column-recommend-10cheweixinxi" class="waterfall-column-recommend-10" :style='{"margin":"0 12rpx 0 0","flex":"1","flexDirection":"column","display":"flex"}'>
					<view @tap="onDetailTap('cheweixinxi',product.id)" :style='{"padding":"0 0 140rpx 0","margin":"0 0 20rpx 0","overflow":"hidden","position":"relative","borderRadius":"12rpx"}' v-for="product in leftListRecommend10cheweixinxi" :key="product.id" class="left-content">
						<image :style='{"border":"6rpx solid #DBADAC","width":"100%","objectFit":"cover","display":"block","height":"auto"}' mode="widthFix" v-if="product.cheweitupian.substring(0,4)=='http'" :src="product.cheweitupian"></image>
						<image :style='{"border":"6rpx solid #DBADAC","width":"100%","objectFit":"cover","display":"block","height":"auto"}' mode="widthFix" v-else :src="product.cheweitupian?baseUrl+product.cheweitupian.split(',')[0]:''"></image>
						<view :style='{"padding":"10rpx 0","overflow":"hidden","left":"0","flexWrap":"wrap","background":"url(http://codegen.caihongy.cn/20231226/62f0e19bf9f44cb7b2947dc4db5e0c4f.png)","bottom":"0","display":"flex","width":"100%","backgroundSize":"100% 100%","position":"absolute","height":"162rpx"}'>
							<view :style='{"padding":"0 20rpx","overflow":"hidden","color":"#000","width":"100%","lineHeight":"40rpx","fontSize":"28rpx","height":"40rpx"}' class="list-item-title">{{product.chechangmingcheng}}</view>
							<view :style='{"padding":"0 20rpx","overflow":"hidden","color":"#000","width":"100%","lineHeight":"40rpx","fontSize":"28rpx","height":"40rpx"}' class="list-item-title">{{product.shoufeibiaozhun}}</view>
							<view :style='{"padding":"0 20rpx","display":"none"}'>
								<text class="icon iconfont icon-shijian21" :style='{"margin":"0 4rpx 0 0","lineHeight":"1.5","fontSize":"24rpx","color":"#fff"}'></text>
								<text :style='{"color":"#fff","lineHeight":"1.5","fontSize":"24rpx"}'>{{product.addtime}}</text>
							</view>
						</view>
					</view>
				</view>
				<view id="waterfall-right-column-recommend-10cheweixinxi" class="waterfall-column-recommend-10" :style='{"margin":"0 0 0 12rpx","flex":"1","flexDirection":"column","display":"flex"}'>
					<view @tap="onDetailTap('cheweixinxi',product.id)" :style='{"padding":"0 0 140rpx 0","margin":"0 0 20rpx 0","overflow":"hidden","position":"relative","borderRadius":"12rpx"}' v-for="product in rightListRecommend10cheweixinxi" :key="product.id" class="right-content">
						<image :style='{"border":"6rpx solid #DBADAC","width":"100%","objectFit":"cover","display":"block","height":"auto"}' mode="widthFix" v-if="product.cheweitupian.substring(0,4)=='http'" :src="product.cheweitupian"></image>
						<image :style='{"border":"6rpx solid #DBADAC","width":"100%","objectFit":"cover","display":"block","height":"auto"}' mode="widthFix" v-else :src="product.cheweitupian?baseUrl+product.cheweitupian.split(',')[0]:''"></image>
						<view :style='{"padding":"10rpx 0","overflow":"hidden","left":"0","flexWrap":"wrap","background":"url(http://codegen.caihongy.cn/20231226/62f0e19bf9f44cb7b2947dc4db5e0c4f.png)","bottom":"0","display":"flex","width":"100%","backgroundSize":"100% 100%","position":"absolute","height":"162rpx"}'>
							<view :style='{"padding":"0 20rpx","overflow":"hidden","color":"#000000","width":"100%","lineHeight":"40rpx","fontSize":"28rpx","height":"40rpx"}' class="list-item-title">{{product.chechangmingcheng}}</view>
							<view :style='{"padding":"0 20rpx","overflow":"hidden","color":"#000000","width":"100%","lineHeight":"40rpx","fontSize":"28rpx","height":"40rpx"}' class="list-item-title">{{product.shoufeibiaozhun}}</view>
							<view :style='{"padding":"0 20rpx","display":"none"}'>
								<text class="icon iconfont icon-shijian21" :style='{"margin":"0 4rpx 0 0","lineHeight":"1.5","fontSize":"24rpx","color":"#fff"}'></text>
								<text :style='{"color":"#fff","lineHeight":"1.5","fontSize":"24rpx"}'>{{product.addtime}}</text>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
		<!-- 商品推荐 -->
		
		<!-- 商品列表 -->
		<view class="listBox list" :style='{"padding":"40rpx 0px","margin":"0","background":"#f5efef","order":"5"}'>
			<view class="title" :style='{"padding":"0 24rpx","margin":"0","background":"url(http://codegen.caihongy.cn/20231226/09d62b9aee0742c8819dd6c606b5f63c.png)","display":"flex","width":"100%","backgroundSize":"100% 100%","position":"relative","justifyContent":"space-between","height":"200rpx"}'>
				<view :style='{"color":"#E34E4E","top":"30rpx","left":"0","textAlign":"center","width":"200rpx","fontSize":"32rpx","lineHeight":"80rpx","position":"relative"}'>停车优惠</view>
				<view :style='{"alignItems":"center","justifyContent":"center","display":"flex"}' @tap="onPageTap('tingcheyouhui')">
				  <text :style='{"color":"#000000","fontSize":"28rpx"}'>更多</text>
				  <text class="icon iconfont icon-gengduo1" :style='{"color":"#000000","fontSize":"28rpx"}'></text>
				</view>
			</view>
			<view id="list-list-10" class="list-box10 waterfall-body" :style='{"width":"100%","padding":"20rpx 24rpx 0","alignItems":"flex-start","display":"flex","height":"auto"}'>
				<view id="waterfall-left-column-list-10tingcheyouhui" class="waterfall-column-list-10" :style='{"margin":"0 12rpx 0 0","flex":"1","flexDirection":"column","display":"flex"}'>
					<view @tap="onDetailTap('tingcheyouhui',product.id)" :style='{"border":"6rpx solid #DBADAC","margin":"0 0 20rpx 0","overflow":"hidden","position":"relative","borderRadius":"12rpx"}' v-for="product in leftListList10tingcheyouhui" :key="product.id" class="left-content">
						<image :style='{"width":"100%","objectFit":"cover","display":"block","height":"auto"}' mode="widthFix" v-if="product.fengmian.substring(0,4)=='http'" :src="product.fengmian"></image>
						<image :style='{"width":"100%","objectFit":"cover","display":"block","height":"auto"}' mode="widthFix" v-else :src="product.fengmian?baseUrl+product.fengmian.split(',')[0]:''"></image>
						<view :style='{"boxShadow":"inset 0rpx 4rpx 10rpx 0rpx #FFFBFB","overflow":"hidden","left":"0","maxHeight":"120rpx","background":"linear-gradient(135deg, rgba(234,206,236,0.5) 0%, rgba(247,203,207,0.5) 100%)","bottom":"0","width":"100%","position":"absolute"}'>
							<view :style='{"padding":"0 20rpx","lineHeight":"40rpx","fontSize":"28rpx","overflow":"hidden","color":"#000000","height":"40rpx"}' class="list-item-title">{{product.chechangmingcheng}}</view>
							<view :style='{"padding":"0 20rpx","display":"none"}'>
								<text class="icon iconfont icon-shijian21" :style='{"margin":"0 4rpx 0 0","lineHeight":"1.5","fontSize":"24rpx","color":"#fff"}'></text>
								<text :style='{"color":"#fff","lineHeight":"1.5","fontSize":"24rpx"}'>{{product.addtime}}</text>
							</view>
						</view>
					</view>
				</view>
				
				<view id="waterfall-right-column-list-10tingcheyouhui" class="waterfall-column-list-10" :style='{"margin":"0 0 0 12rpx","flex":"1","flexDirection":"column","display":"flex"}'>
					<view @tap="onDetailTap('tingcheyouhui',product.id)" :style='{"border":"6rpx solid #DBADAC","margin":"0 0 20rpx 0","overflow":"hidden","position":"relative","borderRadius":"12rpx"}' v-for="product in rightListList10tingcheyouhui" :key="product.id" class="right-content">
						<image :style='{"width":"100%","objectFit":"cover","display":"block","height":"auto"}' mode="widthFix" v-if="product.fengmian.substring(0,4)=='http'" :src="product.fengmian"></image>
						<image :style='{"width":"100%","objectFit":"cover","display":"block","height":"auto"}' mode="widthFix" v-else :src="product.fengmian?baseUrl+product.fengmian.split(',')[0]:''"></image>
						<view :style='{"overflow":"hidden","left":"0","maxHeight":"120rpx","background":"linear-gradient(135deg, rgba(234,206,236,0.5) 0%, rgba(247,203,207,0.5) 100%)","bottom":"0","width":"100%","position":"absolute"}'>
							<view :style='{"padding":"0 20rpx","lineHeight":"40rpx","fontSize":"28rpx","overflow":"hidden","color":"#000000","height":"40rpx "}' class="list-item-title">{{product.chechangmingcheng}}</view>
							<view :style='{"padding":"0 20rpx","display":"none"}'>
								<text class="icon iconfont icon-shijian21" :style='{"margin":"0 4rpx 0 0","lineHeight":"1.5","fontSize":"24rpx","color":"#fff"}'></text>
								<text :style='{"color":"#fff","lineHeight":"1.5","fontSize":"24rpx"}'>{{product.addtime}}</text>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
		<!-- 商品列表 -->
		<!-- 新闻资讯 -->
		<view class="listBox news" :style='{"padding":"40rpx 0px","margin":"0","background":"#f5efef","order":"1"}'>
			<view class="title" :style='{"padding":"0","margin":"0","backgroundImage":"url(http://codegen.caihongy.cn/20231226/09d62b9aee0742c8819dd6c606b5f63c.png)","display":"flex","width":"100%","backgroundSize":"100% 100%","position":"relative","justifyContent":"space-between","height":"200rpx"}'>
				<view :style='{"color":"#E34E4E","top":"20rpx","left":"20rpx","textAlign":"center","width":"200rpx","fontSize":"28rpx","lineHeight":"88rpx","position":"relative"}'>通知中心</view>
				<view :style='{"alignItems":"center","justifyContent":"center","display":"flex"}' @tap="onPageTap('news')">
				  <text :style='{"color":"#000000","fontSize":"28rpx"}'>更多</text>
				  <text class="icon iconfont icon-gengduo1" :style='{"color":"#000000","fontSize":"28rpx"}'></text>
				</view>
			</view>
		  <!-- 样式7 -->
		  <view class="news-box4" :style='{"width":"100%","padding":"24rpx","margin":"0","height":"auto"}'>
			<block v-for="(item,index) in news" :key="index">
			  <view @tap="onNewsDetailTap(item.id)" v-if="index%2==0" class="list-item" :style='{"padding":"40rpx","margin":"0 0 20rpx","flexWrap":"wrap","backgroundImage":"url(http://codegen.caihongy.cn/20231226/1599e65a187a45e2a512504c738395b1.png)","display":"flex","width":"100%","backgroundSize":"100% 100%","height":"auto"}'>
				<image :style='{"width":"180rpx","margin":"12rpx 0 ","objectFit":"cover","borderRadius":"0","display":"block","height":"160rpx"}' mode="aspectFill" class="listmpic" :src="baseUrl+item.picture"></image>
				<view class="list-item-body" :style='{"padding":"0 0 0 60rpx","margin":"0","flexWrap":"wrap","flex":"1","display":"flex","width":"auto","height":"auto"}'>
				  <view :style='{"padding":"0 20rpx","overflow":"hidden","color":"#333","width":"100%","lineHeight":"40rpx","fontSize":"28rpx","height":"40rpx"}' class="title ">{{item.title}}</view>
				  <view :style='{"padding":"0 20rpx","margin":"0","overflow":"hidden","color":"#666","width":"100%","lineHeight":"40rpx","fontSize":"28rpx","height":"40rpx"}' class="text">{{item.introduction}}</view>
				  <view :style='{"padding":"0 20rpx","order":"1"}'>
				    <text class="icon iconfont icon-shijian21" :style='{"margin":"0 4rpx 0 0","lineHeight":"1.5","fontSize":"24rpx","color":"#666"}'></text>
				    <text :style='{"color":"#666","lineHeight":"1.5","fontSize":"24rpx"}'>{{item.addtime}}</text>
				  </view>
				  <view :style='{"padding":"0 20rpx"}'>
				    <text class="icon iconfont icon-geren16" :style='{"margin":"0 4rpx 0 0","lineHeight":"1.5","fontSize":"24rpx","color":"#666"}'></text>
				    <text :style='{"color":"#666","lineHeight":"1.5","fontSize":"24rpx"}'>{{item.name}}</text>
				  </view>
				  <view :style='{"padding":"0 20rpx","display":"inline-block"}'>
				    <text class="icon iconfont icon-zan10" :style='{"margin":"0 4rpx 0 0","lineHeight":"1.5","fontSize":"24rpx","color":"#666"}'></text>
				    <text :style='{"color":"#666","lineHeight":"1.5","fontSize":"24rpx"}'>{{item.thumbsupnum}}</text>
				  </view>
				  <view :style='{"padding":"0 20rpx","display":"inline-block"}'>
				    <text class="icon iconfont icon-shoucang10" :style='{"margin":"0 4rpx 0 0","lineHeight":"1.5","fontSize":"24rpx","color":"#666"}'></text>
				    <text :style='{"color":"#666","lineHeight":"1.5","fontSize":"24rpx"}'>{{item.storeupnum}}</text>
				  </view>
				  <view :style='{"padding":"0 20rpx","display":"inline-block"}'>
				    <text class="icon iconfont icon-chakan9" :style='{"margin":"0 4rpx 0 0","lineHeight":"1.5","fontSize":"24rpx","color":"#666"}'></text>
				    <text :style='{"color":"#666","lineHeight":"1.5","fontSize":"24rpx"}'>{{item.clicknum}}</text>
				  </view>
				</view>
			  </view>
			  <view @tap="onNewsDetailTap(item.id)" v-if="index%2==1" class="list-item" :style='{"padding":"40rpx","margin":"0 0 20rpx","flexWrap":"wrap","backgroundImage":"url(http://codegen.caihongy.cn/20231226/adf00eaf1ac842249bc0e19a03e79a46.png)","display":"flex","width":"auto","backgroundSize":"100% 100%","height":"auto"}'>
				<view class="list-item-body" :style='{"width":"calc(100% - 200rpx)","padding":"0 40rpx 0 0","margin":"0","flexWrap":"wrap","display":"flex","height":"auto"}'>
				  <view :style='{"padding":"0 20rpx","overflow":"hidden","color":"#333","width":"100%","lineHeight":"40rpx","fontSize":"28rpx","height":"40rpx"}' class="title ">{{item.title}}</view>
				  <view :style='{"padding":"0 20rpx","margin":"0","overflow":"hidden","color":"#666","width":"100%","lineHeight":"40rpx","fontSize":"28rpx","height":"40rpx"}' class="text">{{item.introduction}}</view>
				  <view :style='{"padding":"0 20rpx","order":"1"}'>
				    <text class="icon iconfont icon-shijian21" :style='{"margin":"0 4rpx 0 0","lineHeight":"1.5","fontSize":"24rpx","color":"#666"}'></text>
				    <text :style='{"color":"#666","lineHeight":"1.5","fontSize":"24rpx"}'>{{item.addtime}}</text>
				  </view>
				  <view :style='{"padding":"0 20rpx"}'>
				    <text class="icon iconfont icon-geren16" :style='{"margin":"0 4rpx 0 0","lineHeight":"1.5","fontSize":"24rpx","color":"#666"}'></text>
				    <text :style='{"color":"#666","lineHeight":"1.5","fontSize":"24rpx"}'>{{item.name}}</text>
				  </view>
				  <view :style='{"padding":"0 20rpx","display":"inline-block"}'>
				    <text class="icon iconfont icon-zan10" :style='{"margin":"0 4rpx 0 0","lineHeight":"1.5","fontSize":"24rpx","color":"#666"}'></text>
				    <text :style='{"color":"#666","lineHeight":"1.5","fontSize":"24rpx"}'>{{item.thumbsupnum}}</text>
				  </view>
				  <view :style='{"padding":"0 20rpx","display":"inline-block"}'>
				    <text class="icon iconfont icon-shoucang10" :style='{"margin":"0 4rpx 0 0","lineHeight":"1.5","fontSize":"24rpx","color":"#666"}'></text>
				    <text :style='{"color":"#666","lineHeight":"1.5","fontSize":"24rpx"}'>{{item.storeupnum}}</text>
				  </view>
				  <view :style='{"padding":"0 20rpx","display":"inline-block"}'>
				    <text class="icon iconfont icon-chakan9" :style='{"margin":"0 4rpx 0 0","lineHeight":"1.5","fontSize":"24rpx","color":"#666"}'></text>
				    <text :style='{"color":"#666","lineHeight":"1.5","fontSize":"24rpx"}'>{{item.clicknum}}</text>
				  </view>
				</view>
				<image :style='{"width":"180rpx","margin":"14rpx 0 0 20rpx","objectFit":"cover","display":"block","height":"160rpx"}' mode="aspectFill" class="listmpic" :src="baseUrl+item.picture"></image>
			  </view>
			</block>
		  </view>
		</view>
		<!-- 新闻资讯 -->
	</view>
</view>
</template>

<script>
    import menu from '@/utils/menu'
	import '@/assets/css/global-restaurant.css'
	import uniIcons from "@/components/uni-ui/lib/uni-icons/uni-icons.vue"
	export default {
		components: {
			uniIcons
		},
		data() {
			return {
				options2: {
					effect: 'flip',
					loop : true
				},
				options3: {
					effect: 'cube',
					loop : true,
					cubeEffect: {
						shadow: true,
						slideShadows: true,
						shadowOffset: 20,
						shadowScale: 0.94,
					}
				},
				rows: 2,
				column: 4,
				iconArr: [
				  'cuIcon-same',
				  'cuIcon-deliver',
				  'cuIcon-evaluate',
				  'cuIcon-shop',
				  'cuIcon-ticket',
				  'cuIcon-cascades',
				  'cuIcon-discover',
				  'cuIcon-question',
				  'cuIcon-pic',
				  'cuIcon-filter',
				  'cuIcon-footprint',
				  'cuIcon-pulldown',
				  'cuIcon-pullup',
				  'cuIcon-moreandroid',
				  'cuIcon-refund',
				  'cuIcon-qrcode',
				  'cuIcon-remind',
				  'cuIcon-profile',
				  'cuIcon-home',
				  'cuIcon-message',
				  'cuIcon-link',
				  'cuIcon-lock',
				  'cuIcon-unlock',
				  'cuIcon-vip',
				  'cuIcon-weibo',
				  'cuIcon-activity',
				  'cuIcon-friendadd',
				  'cuIcon-friendfamous',
				  'cuIcon-friend',
				  'cuIcon-goods',
				  'cuIcon-selection'
				],
                role : '',
                menuList: [],
                swiperMenuList:[],
                user: {},
                tableName:'',

				//轮播
				swiperList: [],
				cheweixinxilist: [],
				hometingcheyouhuilist: [],
				news: [],
				leftListList10tingcheyouhui: [],
				rightListList10tingcheyouhui: [],
				tempListList10tingcheyouhui: [],
				leftListRecommend10cheweixinxi: [],
				rightListRecommend10cheweixinxi: [],
				tempListRecommend10cheweixinxi: [],
			}
		},
		watch: {
			copyFlowListList10tingcheyouhui(nVal, oVal) {
				this.tempListList10tingcheyouhui = this.cloneData(this.copyFlowListList10tingcheyouhui);
				this.splitDataList10tingcheyouhui();
			},
			copyFlowListRecommend10cheweixinxi(nVal, oVal) {
				this.tempListRecommend10cheweixinxi = this.cloneData(this.copyFlowListRecommend10cheweixinxi);
				this.splitDataRecommend10cheweixinxi();
			},
		},
		mounted() {
			this.tempListList10tingcheyouhui = this.cloneData(this.copyFlowListList10tingcheyouhui);
			this.splitDataList10tingcheyouhui();
			this.tempListRecommend10cheweixinxi = this.cloneData(this.copyFlowListRecommend10cheweixinxi);
			this.splitDataRecommend10cheweixinxi();
		},
		computed: {
			baseUrl() {
				return this.$base.url;
			},
			copyFlowListList10tingcheyouhui() {
				return this.cloneData(this.hometingcheyouhuilist);
			},
			copyFlowListRecommend10cheweixinxi() {
				return this.cloneData(this.cheweixinxilist);
			},
		},
        async onLoad(){
            
        },
		async onShow() {
			this.swiperMenuList = []
			this.role = uni.getStorageSync("appRole");
			let table = uni.getStorageSync("nowTable");
			let res = await this.$api.session(table);
			this.user = res.data;
			this.tableName = table;
			let menus = menu.list();
			this.menuList = menus;
			this.menuList.forEach((item,key) => {
			    if(key==0) {
			        item.frontMenu.forEach((item2,key2) => {
			            if(item2.child[0].buttons.indexOf("查看")>-1) {
			                this.swiperMenuList.push(item2);
			            }
			        })
			    }
			})
            // let res;
			// 轮播图
			let swiperList = []
			res = await this.$api.list('config', {
				page: 1,
				limit: 5
			});
			for (let item of res.data.list) {
				if (item.name.indexOf('picture') >= 0 && item.value && item.value!="" && item.value!=null ) {
					swiperList.push({
						img: item.value,
                        title: item.name,
						url: item.url
					});
				}
			}
			if (swiperList) {
				this.swiperList = swiperList;
			}
			

			this.leftListList10tingcheyouhui = []
			this.rightListList10tingcheyouhui = []
			this.tempListList10tingcheyouhui = []
			// 推荐信息
			this.leftListRecommend10cheweixinxi = []
			this.rightListRecommend10cheweixinxi = []
			this.tempListRecommend10cheweixinxi = []
			this.getRecommendList()
			this.getHomeList()
			this.getNewsList()
		},
		methods: {
			async splitDataList10tingcheyouhui() {
				if (!this.tempListList10tingcheyouhui.length) return;
				let leftRect = await this.uGetRect('#waterfall-left-column-list-10tingcheyouhui');
				let rightRect = await this.uGetRect('#waterfall-right-column-list-10tingcheyouhui');
				// 如果左边小于或等于右边，就添加到左边，否则添加到右边
				let item = this.tempListList10tingcheyouhui[0];
				// 解决多次快速上拉后，可能数据会乱的问题，因为经过上面的两个await节点查询阻塞一定时间，加上后面的定时器干扰
				// 数组可能变成[]，导致此item值可能为undefined
				if (!item) return;
				
				if (leftRect.height < rightRect.height) {
					this.leftListList10tingcheyouhui.push(item);
				} else if (leftRect.height > rightRect.height) {
					this.rightListList10tingcheyouhui.push(item);
				} else {
					// 这里是为了保证第一和第二张添加时，左右都能有内容
					// 因为添加第一张，实际队列的高度可能还是0，这时需要根据队列元素长度判断下一个该放哪边
					if (this.leftListList10tingcheyouhui.length <= this.rightListList10tingcheyouhui.length) {
						this.leftListList10tingcheyouhui.push(item);
					} else {
						this.rightListList10tingcheyouhui.push(item);
					}
				}
				// 移除临时列表的第一项
				this.tempListList10tingcheyouhui.splice(0, 1);
				// 如果临时数组还有数据，继续循环
				if (this.tempListList10tingcheyouhui.length) {
					setTimeout(()=>{
						this.splitDataList10tingcheyouhui();
					}, 150)
					return
				}
			},
			async splitDataRecommend10cheweixinxi() {
				if (!this.tempListRecommend10cheweixinxi.length) return;
				let leftRect = await this.uGetRect('#waterfall-left-column-recommend-10cheweixinxi');
				let rightRect = await this.uGetRect('#waterfall-right-column-recommend-10cheweixinxi');
				// 如果左边小于或等于右边，就添加到左边，否则添加到右边
				let item = this.tempListRecommend10cheweixinxi[0];
				// 解决多次快速上拉后，可能数据会乱的问题，因为经过上面的两个await节点查询阻塞一定时间，加上后面的定时器干扰
				// 数组可能变成[]，导致此item值可能为undefined
				if (!item) return;
				
				if (leftRect.height < rightRect.height) {
					this.leftListRecommend10cheweixinxi.push(item);
				} else if (leftRect.height > rightRect.height) {
					this.rightListRecommend10cheweixinxi.push(item);
				} else {
					// 这里是为了保证第一和第二张添加时，左右都能有内容
					// 因为添加第一张，实际队列的高度可能还是0，这时需要根据队列元素长度判断下一个该放哪边
					if (this.leftListRecommend10cheweixinxi.length <= this.rightListRecommend10cheweixinxi.length) {
						this.leftListRecommend10cheweixinxi.push(item);
					} else {
						this.rightListRecommend10cheweixinxi.push(item);
					}
				}
				// 移除临时列表的第一项
				this.tempListRecommend10cheweixinxi.splice(0, 1);
				// 如果临时数组还有数据，继续循环
				if (this.tempListRecommend10cheweixinxi.length) {
					setTimeout(()=>{
						this.splitDataRecommend10cheweixinxi();
					}, 150)
					return
				}
			},
			uGetRect(selector, all) {
				return new Promise(resolve => {
					uni.createSelectorQuery()
					.in(this)
					[all ? 'selectAll' : 'select'](selector)
					.boundingClientRect(rect => {
						if (all && Array.isArray(rect) && rect.length) {
							resolve(rect);
						}
						if (!all && rect) {
							resolve(rect);
						}
					})
					.exec();
				});
			},
			cloneData(data) {
				return JSON.parse(JSON.stringify(data));
			},
			newsTabClick2(index){
				this.newsIndex2 = index
				this.getNewsList()
			},
			async getNewsList(){
				let res;
				let params = {
					page: 1,
					limit: 6,
					sort: 'id',
					order: 'desc',
				}
				// 通知中心
				res = await this.$api.list('news', params)
				this.news = res.data.list
			},
			homeTabClick2(index,name){
				this['home' + name + 'Index2'] = index
				this.getHomeList()
			},
			async getHomeList(){
				let res;
				let params;
				params = {
					page:1,
					limit: 6,
				}
				res = await this.$api.list('tingcheyouhui', params);
				this.hometingcheyouhuilist = res.data.list
				this.tempListList10tingcheyouhui = this.copyFlowListList10tingcheyouhui;
				this.splitDataList10tingcheyouhui();
			},
			recommendTabClick2(index,name){
				this[name + 'Index2'] = index
				this.getRecommendList()
			},
			async getRecommendList(){
				let res;
				let params;
				// 推荐信息
				params = {
					page: 1,
					limit: 6,
				}
				res = await this.$api.recommend('cheweixinxi', params);
				this.cheweixinxilist = res.data.list
				
				this.tempListRecommend10cheweixinxi = this.copyFlowListRecommend10cheweixinxi;
				this.splitDataRecommend10cheweixinxi();

			},
			//轮播图跳转
			onSwiperTap(e) {
				if(e.url) {
					if (e.url.indexOf('https') != -1) {
						window.open(e.url)
					} else {
						this.$utils.jump(e.url)
					}
				}
			},
			// 新闻详情
			onNewsDetailTap(id) {
				this.$utils.jump(`../news-detail/news-detail?id=${id}`)
			},
			// 推荐列表点击详情
			onDetailTap(tableName, id) {
				this.$utils.jump(`../${tableName}/detail?id=${id}`)
			},
			onPageTap(tableName){

				uni.navigateTo({
					url: `../${tableName}/list`,
					fail: function(){
						uni.switchTab({
							url: `../${tableName}/list`
						});
					}
				});
				// this.$utils.jump(`../${tableName}/list`)
			},
            onPageTap2(url) {
                uni.setStorageSync("useridTag",0);
                uni.navigateTo({
                    url: url,
                    fail: function() {
                        uni.switchTab({
                            url: url
                        });
                    }
                });
            }
		}
	}
</script>

<style lang="scss" scoped>
	.content {
		min-height: calc(100vh - 44px);
		box-sizing: border-box;
	}

</style>
