<template>
<view class="content">
	<view class="box" :style='{"width":"100%","padding":"0 20% 0 0","backgroundSize":"100% 100%","backgroundImage":"url(http://codegen.caihongy.cn/20231226/8160bcbd61bd4e3095281772c10e1f9d.png)","height":"100%"}'>
		<view :style='{"padding":"100rpx 24rpx 0","borderRadius":"0 30pt 60rpx 0","background":"#fff","display":"block","width":"100%","position":"relative","height":"100%"}'>
			<image :style='{"width":"160rpx","margin":"0 auto 24rpx auto","borderRadius":"8rpx","display":"none","height":"160rpx"}' src="http://codegen.caihongy.cn/20201114/7856ba26477849ea828f481fa2773a95.jpg" mode="aspectFill"></image>
			<view :style='{"width":"100%","margin":"0 0 24rpx 0","display":"flex","height":"auto"}' v-if="tableName=='yonghu'" class="uni-form-item uni-column">
				<view :style='{"width":"240rpx","lineHeight":"88rpx","fontSize":"28rpx","color":"#000"}' class="label">用户账号：</view>
				<input :style='{"border":"0px solid rgb(255, 170, 51)","padding":"0px 24rpx","boxShadow":"0 2rpx 0 #B991BC","margin":"0px","color":"rgb(0, 0, 0)","borderRadius":"0","background":"rgb(255, 255, 255)","width":"calc(100% - 260rpx)","fontSize":"28rpx","height":"88rpx"}'  v-model="ruleForm.yonghuzhanghao"  type="text"  class="uni-input" name="" placeholder="用户账号" />
			</view>
			<view :style='{"width":"100%","margin":"0 0 24rpx 0","display":"flex","height":"auto"}' v-if="tableName=='yonghu'" class="uni-form-item uni-column">
				<view :style='{"width":"240rpx","lineHeight":"88rpx","fontSize":"28rpx","color":"#000"}' class="label">密码：</view>
				<input :style='{"border":"0px solid rgb(255, 170, 51)","padding":"0px 24rpx","boxShadow":"0 2rpx 0 #B991BC","margin":"0px","color":"rgb(0, 0, 0)","borderRadius":"0","background":"rgb(255, 255, 255)","width":"calc(100% - 260rpx)","fontSize":"28rpx","height":"88rpx"}'  v-model="ruleForm.mima" type="password"  class="uni-input" name="" placeholder="密码" />
			</view>
			<view :style='{"width":"100%","margin":"0 0 24rpx 0","display":"flex","height":"auto"}' v-if="tableName=='yonghu'" class="uni-form-item uni-column">
				<view :style='{"width":"240rpx","lineHeight":"88rpx","fontSize":"28rpx","color":"#000"}' class="label">确认密码：</view>
				<input :style='{"border":"0px solid rgb(255, 170, 51)","padding":"0px 24rpx","boxShadow":"0 2rpx 0 #B991BC","margin":"0px","color":"rgb(0, 0, 0)","borderRadius":"0","background":"rgb(255, 255, 255)","width":"calc(100% - 260rpx)","fontSize":"28rpx","height":"88rpx"}' v-model="ruleForm.mima2" type="password" class="uni-input" name="" placeholder="确认密码" />
			</view>
			<view :style='{"width":"100%","margin":"0 0 24rpx 0","display":"flex","height":"auto"}' v-if="tableName=='yonghu'" class="uni-form-item uni-column">
				<view :style='{"width":"240rpx","lineHeight":"88rpx","fontSize":"28rpx","color":"#000"}' class="label">用户姓名：</view>
				<input :style='{"border":"0px solid rgb(255, 170, 51)","padding":"0px 24rpx","boxShadow":"0 2rpx 0 #B991BC","margin":"0px","color":"rgb(0, 0, 0)","borderRadius":"0","background":"rgb(255, 255, 255)","width":"calc(100% - 260rpx)","fontSize":"28rpx","height":"88rpx"}'  v-model="ruleForm.yonghuxingming"  type="text"  class="uni-input" name="" placeholder="用户姓名" />
			</view>
            <view :style='{"width":"100%","margin":"0 0 24rpx 0","display":"flex","height":"auto"}' v-if="tableName=='yonghu'" @tap="yonghutouxiangTap" class="">
				<view :style='{"width":"240rpx","lineHeight":"88rpx","fontSize":"28rpx","color":"#000"}' class="label">头像：</view>
				<image :style='{"width":"100rpx","borderRadius":"16rpx","display":"block","height":"100rpx"}' v-if="ruleForm.touxiang" class="avator" :src="baseUrl+ruleForm.touxiang" mode=""></image>
                <image :style='{"width":"100rpx","borderRadius":"16rpx","display":"block","height":"100rpx"}' v-else class="avator" src="../../static/gen/upload.png" mode=""></image>
            </view>
            <view :style='{"width":"100%","margin":"0 0 24rpx 0","display":"flex","height":"auto"}' v-if="tableName=='yonghu'" class="">
				<view :style='{"width":"240rpx","lineHeight":"88rpx","fontSize":"28rpx","color":"#000"}' class="label">性别：</view>
				<picker :style='{"width":"100%","margin":"0 0 24rpx 0","display":"flex","height":"auto"}' v-if="tableName=='yonghu'"  @change="yonghuxingbieChange" :value="yonghuxingbieIndex" :range="yonghuxingbieOptions">
					<view>
						<view :style='{"lineHeight":"88rpx","fontSize":"28rpx","color":"#000","flex":"1"}' class="uni-input">{{ruleForm.xingbie?ruleForm.xingbie:"请选择性别"}}</view>
					</view>
				</picker>
			</view>
			<view :style='{"width":"100%","margin":"0 0 24rpx 0","display":"flex","height":"auto"}' v-if="tableName=='yonghu'" class="uni-form-item uni-column">
				<view :style='{"width":"240rpx","lineHeight":"88rpx","fontSize":"28rpx","color":"#000"}' class="label">年龄：</view>
				<input :style='{"border":"0px solid rgb(255, 170, 51)","padding":"0px 24rpx","boxShadow":"0 2rpx 0 #B991BC","margin":"0px","color":"rgb(0, 0, 0)","borderRadius":"0","background":"rgb(255, 255, 255)","width":"calc(100% - 260rpx)","fontSize":"28rpx","height":"88rpx"}'  v-model="ruleForm.nianling"  type="text"  class="uni-input" name="" placeholder="年龄" />
			</view>
			<view :style='{"width":"100%","margin":"0 0 24rpx 0","display":"flex","height":"auto"}' v-if="tableName=='yonghu'" class="uni-form-item uni-column">
				<view :style='{"width":"240rpx","lineHeight":"88rpx","fontSize":"28rpx","color":"#000"}' class="label">手机号码：</view>
				<input :style='{"border":"0px solid rgb(255, 170, 51)","padding":"0px 24rpx","boxShadow":"0 2rpx 0 #B991BC","margin":"0px","color":"rgb(0, 0, 0)","borderRadius":"0","background":"rgb(255, 255, 255)","width":"calc(100% - 260rpx)","fontSize":"28rpx","height":"88rpx"}'  v-model="ruleForm.shoujihaoma"  type="text"  class="uni-input" name="" placeholder="手机号码" />
			</view>
			<view :style='{"width":"100%","margin":"0 0 24rpx 0","display":"flex","height":"auto"}' v-if="tableName=='yonghu'" class="uni-form-item uni-column">
				<view :style='{"width":"240rpx","lineHeight":"88rpx","fontSize":"28rpx","color":"#000"}' class="label">身份证号：</view>
				<input :style='{"border":"0px solid rgb(255, 170, 51)","padding":"0px 24rpx","boxShadow":"0 2rpx 0 #B991BC","margin":"0px","color":"rgb(0, 0, 0)","borderRadius":"0","background":"rgb(255, 255, 255)","width":"calc(100% - 260rpx)","fontSize":"28rpx","height":"88rpx"}'  v-model="ruleForm.shenfenzhenghao"  type="text"  class="uni-input" name="" placeholder="身份证号" />
			</view>
			<view :style='{"width":"100%","margin":"0 0 24rpx 0","display":"flex","height":"auto"}' v-if="tableName=='yuangong'" class="uni-form-item uni-column">
				<view :style='{"width":"240rpx","lineHeight":"88rpx","fontSize":"28rpx","color":"#000"}' class="label">员工工号：</view>
				<input :style='{"border":"0px solid rgb(255, 170, 51)","padding":"0px 24rpx","boxShadow":"0 2rpx 0 #B991BC","margin":"0px","color":"rgb(0, 0, 0)","borderRadius":"0","background":"rgb(255, 255, 255)","width":"calc(100% - 260rpx)","fontSize":"28rpx","height":"88rpx"}'  v-model="ruleForm.yuangonggonghao"  type="text"  class="uni-input" name="" placeholder="员工工号" />
			</view>
			<view :style='{"width":"100%","margin":"0 0 24rpx 0","display":"flex","height":"auto"}' v-if="tableName=='yuangong'" class="uni-form-item uni-column">
				<view :style='{"width":"240rpx","lineHeight":"88rpx","fontSize":"28rpx","color":"#000"}' class="label">密码：</view>
				<input :style='{"border":"0px solid rgb(255, 170, 51)","padding":"0px 24rpx","boxShadow":"0 2rpx 0 #B991BC","margin":"0px","color":"rgb(0, 0, 0)","borderRadius":"0","background":"rgb(255, 255, 255)","width":"calc(100% - 260rpx)","fontSize":"28rpx","height":"88rpx"}'  v-model="ruleForm.mima" type="password"  class="uni-input" name="" placeholder="密码" />
			</view>
			<view :style='{"width":"100%","margin":"0 0 24rpx 0","display":"flex","height":"auto"}' v-if="tableName=='yuangong'" class="uni-form-item uni-column">
				<view :style='{"width":"240rpx","lineHeight":"88rpx","fontSize":"28rpx","color":"#000"}' class="label">确认密码：</view>
				<input :style='{"border":"0px solid rgb(255, 170, 51)","padding":"0px 24rpx","boxShadow":"0 2rpx 0 #B991BC","margin":"0px","color":"rgb(0, 0, 0)","borderRadius":"0","background":"rgb(255, 255, 255)","width":"calc(100% - 260rpx)","fontSize":"28rpx","height":"88rpx"}' v-model="ruleForm.mima2" type="password" class="uni-input" name="" placeholder="确认密码" />
			</view>
			<view :style='{"width":"100%","margin":"0 0 24rpx 0","display":"flex","height":"auto"}' v-if="tableName=='yuangong'" class="uni-form-item uni-column">
				<view :style='{"width":"240rpx","lineHeight":"88rpx","fontSize":"28rpx","color":"#000"}' class="label">员工姓名：</view>
				<input :style='{"border":"0px solid rgb(255, 170, 51)","padding":"0px 24rpx","boxShadow":"0 2rpx 0 #B991BC","margin":"0px","color":"rgb(0, 0, 0)","borderRadius":"0","background":"rgb(255, 255, 255)","width":"calc(100% - 260rpx)","fontSize":"28rpx","height":"88rpx"}'  v-model="ruleForm.yuangongxingming"  type="text"  class="uni-input" name="" placeholder="员工姓名" />
			</view>
            <view :style='{"width":"100%","margin":"0 0 24rpx 0","display":"flex","height":"auto"}' v-if="tableName=='yuangong'" class="">
				<view :style='{"width":"240rpx","lineHeight":"88rpx","fontSize":"28rpx","color":"#000"}' class="label">性别：</view>
				<picker :style='{"width":"100%","margin":"0 0 24rpx 0","display":"flex","height":"auto"}' v-if="tableName=='yuangong'"  @change="yuangongxingbieChange" :value="yuangongxingbieIndex" :range="yuangongxingbieOptions">
					<view>
						<view :style='{"lineHeight":"88rpx","fontSize":"28rpx","color":"#000","flex":"1"}' class="uni-input">{{ruleForm.xingbie?ruleForm.xingbie:"请选择性别"}}</view>
					</view>
				</picker>
			</view>
			<view :style='{"width":"100%","margin":"0 0 24rpx 0","display":"flex","height":"auto"}' v-if="tableName=='yuangong'" class="uni-form-item uni-column">
				<view :style='{"width":"240rpx","lineHeight":"88rpx","fontSize":"28rpx","color":"#000"}' class="label">年龄：</view>
				<input :style='{"border":"0px solid rgb(255, 170, 51)","padding":"0px 24rpx","boxShadow":"0 2rpx 0 #B991BC","margin":"0px","color":"rgb(0, 0, 0)","borderRadius":"0","background":"rgb(255, 255, 255)","width":"calc(100% - 260rpx)","fontSize":"28rpx","height":"88rpx"}'  v-model="ruleForm.nianling"  type="text"  class="uni-input" name="" placeholder="年龄" />
			</view>
			<view :style='{"width":"100%","margin":"0 0 24rpx 0","display":"flex","height":"auto"}' v-if="tableName=='yuangong'" class="uni-form-item uni-column">
				<view :style='{"width":"240rpx","lineHeight":"88rpx","fontSize":"28rpx","color":"#000"}' class="label">手机号：</view>
				<input :style='{"border":"0px solid rgb(255, 170, 51)","padding":"0px 24rpx","boxShadow":"0 2rpx 0 #B991BC","margin":"0px","color":"rgb(0, 0, 0)","borderRadius":"0","background":"rgb(255, 255, 255)","width":"calc(100% - 260rpx)","fontSize":"28rpx","height":"88rpx"}'  v-model="ruleForm.shoujihao"  type="text"  class="uni-input" name="" placeholder="手机号" />
			</view>
			<view :style='{"width":"100%","margin":"0 0 24rpx 0","display":"flex","height":"auto"}' v-if="tableName=='yuangong'" class="uni-form-item uni-column">
				<view :style='{"width":"240rpx","lineHeight":"88rpx","fontSize":"28rpx","color":"#000"}' class="label">身份证号：</view>
				<input :style='{"border":"0px solid rgb(255, 170, 51)","padding":"0px 24rpx","boxShadow":"0 2rpx 0 #B991BC","margin":"0px","color":"rgb(0, 0, 0)","borderRadius":"0","background":"rgb(255, 255, 255)","width":"calc(100% - 260rpx)","fontSize":"28rpx","height":"88rpx"}'  v-model="ruleForm.shenfenzhenghao"  type="text"  class="uni-input" name="" placeholder="身份证号" />
			</view>
            <view :style='{"width":"100%","margin":"0 0 24rpx 0","display":"flex","height":"auto"}' v-if="tableName=='yuangong'" @tap="yuangongzhaopianTap" class="">
				<view :style='{"width":"240rpx","lineHeight":"88rpx","fontSize":"28rpx","color":"#000"}' class="label">照片：</view>
				<image :style='{"width":"100rpx","borderRadius":"16rpx","display":"block","height":"100rpx"}' v-if="ruleForm.zhaopian" class="avator" :src="baseUrl+ruleForm.zhaopian" mode=""></image>
                <image :style='{"width":"100rpx","borderRadius":"16rpx","display":"block","height":"100rpx"}' v-else class="avator" src="../../static/gen/upload.png" mode=""></image>
            </view>
			<view :style='{"width":"100%","margin":"0 0 24rpx 0","display":"flex","height":"auto"}' v-if="tableName=='yuangong'" class="uni-form-item uni-column">
				<view :style='{"width":"240rpx","lineHeight":"88rpx","fontSize":"28rpx","color":"#000"}' class="label">家庭住址：</view>
				<input :style='{"border":"0px solid rgb(255, 170, 51)","padding":"0px 24rpx","boxShadow":"0 2rpx 0 #B991BC","margin":"0px","color":"rgb(0, 0, 0)","borderRadius":"0","background":"rgb(255, 255, 255)","width":"calc(100% - 260rpx)","fontSize":"28rpx","height":"88rpx"}'  v-model="ruleForm.jiatingzhuzhi"  type="text"  class="uni-input" name="" placeholder="家庭住址" />
			</view>
			<button :style='{"border":"0","padding":"60rpx 0","margin":"0 auto 24rpx 200rpx","color":"#000","borderRadius":"8rpx","background":"url(http://codegen.caihongy.cn/20231226/54ab8a167fdd413ea38a69b48eab85a6.png) ","width":"160rpx","lineHeight":"40rpx","fontSize":"32rpx","backgroundSize":"100% 100%","height":"160rpx"}' class="btn-submit" @tap="register" type="primary">注册</button>
			
			<view class="idea1" :style='{"width":"100%","background":"red","display":"none","height":"80rpx"}'>idea1</view>
			<view class="idea2" :style='{"width":"100%","background":"red","display":"none","height":"80rpx"}'>idea2</view>
			<view class="idea3" :style='{"width":"100%","background":"red","display":"none","height":"80rpx"}'>idea3</view>
		</view>
	</view>
</view>
</template>

<script>
    import multipleSelect from "@/components/momo-multipleSelect/momo-multipleSelect";
	export default {
		data() {
			return {
                yonghuxingbieOptions: [],
                yonghuxingbieIndex: 0,
                yuangongxingbieOptions: [],
                yuangongxingbieIndex: 0,
				ruleForm: {
                yonghuzhanghao: '',
                mima: '',
                yonghuxingming: '',
                touxiang: '',
                xingbie: '',
                nianling: '',
                shoujihaoma: '',
                shenfenzhenghao: '',
                yuangonggonghao: '',
                mima: '',
                yuangongxingming: '',
                xingbie: '',
                nianling: '',
                shoujihao: '',
                shenfenzhenghao: '',
                zhaopian: '',
                jiatingzhuzhi: '',
				},
				tableName:""
			}
		},
        components: {
            multipleSelect
        },
        computed: {
            baseUrl() {
                return this.$base.url;
            },
        },
		async onLoad() {
			let res = [];
			let table = uni.getStorageSync("loginTable");
            this.tableName = table;

                        // 自定义下拉框值
			if(this.tableName=='yonghu'){
                this.yonghuxingbieOptions = "男,女".split(',');
				this.ruleForm.xingbie=this.yonghuxingbieOptions[0]
			}
                        // 自定义下拉框值
			if(this.tableName=='yuangong'){
                this.yuangongxingbieOptions = "男,女".split(',');
				this.ruleForm.xingbie=this.yuangongxingbieOptions[0]
			}
			
			this.styleChange()
		},
		methods: {

            yonghutouxiangTap() {
                let _this = this;
                this.$api.upload(function(res) {
                    _this.ruleForm.touxiang = 'upload/' + res.file;
					_this.$forceUpdate();
                });
            },
            // 下拉变化
            yonghuxingbieChange(e) {
                    this.yonghuxingbieIndex = e.target.value
                    this.ruleForm.xingbie = this.yonghuxingbieOptions[this.yonghuxingbieIndex]
            },
            // 下拉变化
            yuangongxingbieChange(e) {
                    this.yuangongxingbieIndex = e.target.value
                    this.ruleForm.xingbie = this.yuangongxingbieOptions[this.yuangongxingbieIndex]
            },
            yuangongzhaopianTap() {
                let _this = this;
                this.$api.upload(function(res) {
                    _this.ruleForm.zhaopian = 'upload/' + res.file;
					_this.$forceUpdate();
                });
            },

            toggleTab(str) {
                this.$refs[str].show();
            },

			styleChange() {
				this.$nextTick(()=>{
					// document.querySelectorAll('.uni-input .uni-input-input').forEach(el=>{
					//   el.style.backgroundColor = this.registerFrom.content.input.backgroundColor
					// })
				})
			},
			// 获取uuid
			getUUID () {
				return new Date().getTime();
			},
			// 注册
			async register() {
				
				if((!this.ruleForm.yonghuzhanghao) && `yonghu` == this.tableName){
					this.$utils.msg(`用户账号不能为空`);
					return
				}
				if((!this.ruleForm.mima) && `yonghu` == this.tableName){
					this.$utils.msg(`密码不能为空`);
					return
				}
                if(`yonghu` == this.tableName && (this.ruleForm.mima!=this.ruleForm.mima2)){
                    this.$utils.msg(`两次密码输入不一致`);
                    return
                }
				if((!this.ruleForm.yonghuxingming) && `yonghu` == this.tableName){
					this.$utils.msg(`用户姓名不能为空`);
					return
				}
				if(`yonghu` == this.tableName && this.ruleForm.nianling&&(!this.$validate.isIntNumer(this.ruleForm.nianling))){
					this.$utils.msg(`年龄应输入整数`);
					return
				}
				if((!this.ruleForm.shoujihaoma) && `yonghu` == this.tableName){
					this.$utils.msg(`手机号码不能为空`);
					return
				}
				if(`yonghu` == this.tableName && this.ruleForm.shoujihaoma&&(!this.$validate.isMobile(this.ruleForm.shoujihaoma))){
					this.$utils.msg(`手机号码应输入手机格式`);
					return
				}
				if(`yonghu` == this.tableName && this.ruleForm.shenfenzhenghao&&(!this.$validate.checkIdCard(this.ruleForm.shenfenzhenghao))){
					this.$utils.msg(`身份证号应输入身份证格式`);
					return
				}
				if((!this.ruleForm.yuangonggonghao) && `yuangong` == this.tableName){
					this.$utils.msg(`员工工号不能为空`);
					return
				}
				if((!this.ruleForm.mima) && `yuangong` == this.tableName){
					this.$utils.msg(`密码不能为空`);
					return
				}
                if(`yuangong` == this.tableName && (this.ruleForm.mima!=this.ruleForm.mima2)){
                    this.$utils.msg(`两次密码输入不一致`);
                    return
                }
				if((!this.ruleForm.yuangongxingming) && `yuangong` == this.tableName){
					this.$utils.msg(`员工姓名不能为空`);
					return
				}
				if(`yuangong` == this.tableName && this.ruleForm.nianling&&(!this.$validate.isIntNumer(this.ruleForm.nianling))){
					this.$utils.msg(`年龄应输入整数`);
					return
				}
				if(`yuangong` == this.tableName && this.ruleForm.shoujihao&&(!this.$validate.isMobile(this.ruleForm.shoujihao))){
					this.$utils.msg(`手机号应输入手机格式`);
					return
				}
				if(`yuangong` == this.tableName && this.ruleForm.shenfenzhenghao&&(!this.$validate.checkIdCard(this.ruleForm.shenfenzhenghao))){
					this.$utils.msg(`身份证号应输入身份证格式`);
					return
				}
				await this.$api.register(`${this.tableName}`, this.ruleForm);
				this.$utils.msgBack('注册成功');;
			}
		}
	}
</script>

<style lang="scss" scoped>
	.content {
		min-height: calc(100vh - 44px);
		box-sizing: border-box;
	}
</style>
