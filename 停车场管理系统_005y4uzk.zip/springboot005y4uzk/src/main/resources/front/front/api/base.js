﻿const base = {
    url : "http://localhost:8080/springboot005y4uzk/"
}
export default base
