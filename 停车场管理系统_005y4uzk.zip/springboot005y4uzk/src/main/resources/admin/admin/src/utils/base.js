const base = {
    get() {
        return {
            url : "http://localhost:8080/springboot005y4uzk/",
            name: "springboot005y4uzk",
            // 退出到首页链接
            indexUrl: 'http://localhost:8080/springboot005y4uzk/front/h5/index.html'
        };
    },
    getProjectName(){
        return {
            projectName: "停车场管理系统"
        } 
    }
}
export default base
