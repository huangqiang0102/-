package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.JiesuanlichangEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.JiesuanlichangVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.JiesuanlichangView;


/**
 * 结算离场
 *
 * @author 
 * @email 
 * @date 2024-04-04 13:20:43
 */
public interface JiesuanlichangService extends IService<JiesuanlichangEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<JiesuanlichangVO> selectListVO(Wrapper<JiesuanlichangEntity> wrapper);
   	
   	JiesuanlichangVO selectVO(@Param("ew") Wrapper<JiesuanlichangEntity> wrapper);
   	
   	List<JiesuanlichangView> selectListView(Wrapper<JiesuanlichangEntity> wrapper);
   	
   	JiesuanlichangView selectView(@Param("ew") Wrapper<JiesuanlichangEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<JiesuanlichangEntity> wrapper);

   	

}

