package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.FankuijiluEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.FankuijiluVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.FankuijiluView;


/**
 * 反馈记录
 *
 * @author 
 * @email 
 * @date 2024-04-04 13:20:43
 */
public interface FankuijiluService extends IService<FankuijiluEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<FankuijiluVO> selectListVO(Wrapper<FankuijiluEntity> wrapper);
   	
   	FankuijiluVO selectVO(@Param("ew") Wrapper<FankuijiluEntity> wrapper);
   	
   	List<FankuijiluView> selectListView(Wrapper<FankuijiluEntity> wrapper);
   	
   	FankuijiluView selectView(@Param("ew") Wrapper<FankuijiluEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<FankuijiluEntity> wrapper);

   	

}

