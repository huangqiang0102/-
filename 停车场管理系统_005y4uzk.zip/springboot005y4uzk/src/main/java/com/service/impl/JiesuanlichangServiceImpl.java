package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.JiesuanlichangDao;
import com.entity.JiesuanlichangEntity;
import com.service.JiesuanlichangService;
import com.entity.vo.JiesuanlichangVO;
import com.entity.view.JiesuanlichangView;

@Service("jiesuanlichangService")
public class JiesuanlichangServiceImpl extends ServiceImpl<JiesuanlichangDao, JiesuanlichangEntity> implements JiesuanlichangService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<JiesuanlichangEntity> page = this.selectPage(
                new Query<JiesuanlichangEntity>(params).getPage(),
                new EntityWrapper<JiesuanlichangEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<JiesuanlichangEntity> wrapper) {
		  Page<JiesuanlichangView> page =new Query<JiesuanlichangView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}

    
    @Override
	public List<JiesuanlichangVO> selectListVO(Wrapper<JiesuanlichangEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public JiesuanlichangVO selectVO(Wrapper<JiesuanlichangEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<JiesuanlichangView> selectListView(Wrapper<JiesuanlichangEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public JiesuanlichangView selectView(Wrapper<JiesuanlichangEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
