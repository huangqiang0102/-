package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.TingcheyouhuiDao;
import com.entity.TingcheyouhuiEntity;
import com.service.TingcheyouhuiService;
import com.entity.vo.TingcheyouhuiVO;
import com.entity.view.TingcheyouhuiView;

@Service("tingcheyouhuiService")
public class TingcheyouhuiServiceImpl extends ServiceImpl<TingcheyouhuiDao, TingcheyouhuiEntity> implements TingcheyouhuiService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<TingcheyouhuiEntity> page = this.selectPage(
                new Query<TingcheyouhuiEntity>(params).getPage(),
                new EntityWrapper<TingcheyouhuiEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<TingcheyouhuiEntity> wrapper) {
		  Page<TingcheyouhuiView> page =new Query<TingcheyouhuiView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}

    
    @Override
	public List<TingcheyouhuiVO> selectListVO(Wrapper<TingcheyouhuiEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public TingcheyouhuiVO selectVO(Wrapper<TingcheyouhuiEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<TingcheyouhuiView> selectListView(Wrapper<TingcheyouhuiEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public TingcheyouhuiView selectView(Wrapper<TingcheyouhuiEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
