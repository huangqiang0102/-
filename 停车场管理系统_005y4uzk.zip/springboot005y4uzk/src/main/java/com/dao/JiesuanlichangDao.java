package com.dao;

import com.entity.JiesuanlichangEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.JiesuanlichangVO;
import com.entity.view.JiesuanlichangView;


/**
 * 结算离场
 * 
 * @author 
 * @email 
 * @date 2024-04-04 13:20:43
 */
public interface JiesuanlichangDao extends BaseMapper<JiesuanlichangEntity> {
	
	List<JiesuanlichangVO> selectListVO(@Param("ew") Wrapper<JiesuanlichangEntity> wrapper);
	
	JiesuanlichangVO selectVO(@Param("ew") Wrapper<JiesuanlichangEntity> wrapper);
	
	List<JiesuanlichangView> selectListView(@Param("ew") Wrapper<JiesuanlichangEntity> wrapper);

	List<JiesuanlichangView> selectListView(Pagination page,@Param("ew") Wrapper<JiesuanlichangEntity> wrapper);

	
	JiesuanlichangView selectView(@Param("ew") Wrapper<JiesuanlichangEntity> wrapper);
	

}
