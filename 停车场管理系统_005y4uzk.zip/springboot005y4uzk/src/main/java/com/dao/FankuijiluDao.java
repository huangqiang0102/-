package com.dao;

import com.entity.FankuijiluEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.FankuijiluVO;
import com.entity.view.FankuijiluView;


/**
 * 反馈记录
 * 
 * @author 
 * @email 
 * @date 2024-04-04 13:20:43
 */
public interface FankuijiluDao extends BaseMapper<FankuijiluEntity> {
	
	List<FankuijiluVO> selectListVO(@Param("ew") Wrapper<FankuijiluEntity> wrapper);
	
	FankuijiluVO selectVO(@Param("ew") Wrapper<FankuijiluEntity> wrapper);
	
	List<FankuijiluView> selectListView(@Param("ew") Wrapper<FankuijiluEntity> wrapper);

	List<FankuijiluView> selectListView(Pagination page,@Param("ew") Wrapper<FankuijiluEntity> wrapper);

	
	FankuijiluView selectView(@Param("ew") Wrapper<FankuijiluEntity> wrapper);
	

}
