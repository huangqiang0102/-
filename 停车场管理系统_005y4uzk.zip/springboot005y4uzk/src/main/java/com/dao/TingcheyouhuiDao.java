package com.dao;

import com.entity.TingcheyouhuiEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.TingcheyouhuiVO;
import com.entity.view.TingcheyouhuiView;


/**
 * 停车优惠
 * 
 * @author 
 * @email 
 * @date 2024-04-04 13:20:43
 */
public interface TingcheyouhuiDao extends BaseMapper<TingcheyouhuiEntity> {
	
	List<TingcheyouhuiVO> selectListVO(@Param("ew") Wrapper<TingcheyouhuiEntity> wrapper);
	
	TingcheyouhuiVO selectVO(@Param("ew") Wrapper<TingcheyouhuiEntity> wrapper);
	
	List<TingcheyouhuiView> selectListView(@Param("ew") Wrapper<TingcheyouhuiEntity> wrapper);

	List<TingcheyouhuiView> selectListView(Pagination page,@Param("ew") Wrapper<TingcheyouhuiEntity> wrapper);

	
	TingcheyouhuiView selectView(@Param("ew") Wrapper<TingcheyouhuiEntity> wrapper);
	

}
