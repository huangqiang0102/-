package com.entity.vo;

import com.entity.NewstypeEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
 

/**
 * 通知中心分类
 * @author 
 * @email 
 * @date 2024-04-04 13:20:43
 */
public class NewstypeVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 				
}
