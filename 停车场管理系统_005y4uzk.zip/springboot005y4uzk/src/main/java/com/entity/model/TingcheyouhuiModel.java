package com.entity.model;

import com.entity.TingcheyouhuiEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
 

/**
 * 停车优惠
 * 接收传参的实体类  
 *（实际开发中配合移动端接口开发手动去掉些没用的字段， 后端一般用entity就够用了） 
 * 取自ModelAndView 的model名称
 * @author 
 * @email 
 * @date 2024-04-04 13:20:43
 */
public class TingcheyouhuiModel  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 车场类型
	 */
	
	private String chechangleixing;
		
	/**
	 * 封面
	 */
	
	private String fengmian;
		
	/**
	 * 位置
	 */
	
	private String weizhi;
		
	/**
	 * 咨询电话
	 */
	
	private String zixundianhua;
		
	/**
	 * 车位数量
	 */
	
	private Integer cheweishuliang;
		
	/**
	 * 备注
	 */
	
	private String beizhu;
		
	/**
	 * 停车优惠
	 */
	
	private String tingcheyouhui;
				
	
	/**
	 * 设置：车场类型
	 */
	 
	public void setChechangleixing(String chechangleixing) {
		this.chechangleixing = chechangleixing;
	}
	
	/**
	 * 获取：车场类型
	 */
	public String getChechangleixing() {
		return chechangleixing;
	}
				
	
	/**
	 * 设置：封面
	 */
	 
	public void setFengmian(String fengmian) {
		this.fengmian = fengmian;
	}
	
	/**
	 * 获取：封面
	 */
	public String getFengmian() {
		return fengmian;
	}
				
	
	/**
	 * 设置：位置
	 */
	 
	public void setWeizhi(String weizhi) {
		this.weizhi = weizhi;
	}
	
	/**
	 * 获取：位置
	 */
	public String getWeizhi() {
		return weizhi;
	}
				
	
	/**
	 * 设置：咨询电话
	 */
	 
	public void setZixundianhua(String zixundianhua) {
		this.zixundianhua = zixundianhua;
	}
	
	/**
	 * 获取：咨询电话
	 */
	public String getZixundianhua() {
		return zixundianhua;
	}
				
	
	/**
	 * 设置：车位数量
	 */
	 
	public void setCheweishuliang(Integer cheweishuliang) {
		this.cheweishuliang = cheweishuliang;
	}
	
	/**
	 * 获取：车位数量
	 */
	public Integer getCheweishuliang() {
		return cheweishuliang;
	}
				
	
	/**
	 * 设置：备注
	 */
	 
	public void setBeizhu(String beizhu) {
		this.beizhu = beizhu;
	}
	
	/**
	 * 获取：备注
	 */
	public String getBeizhu() {
		return beizhu;
	}
				
	
	/**
	 * 设置：停车优惠
	 */
	 
	public void setTingcheyouhui(String tingcheyouhui) {
		this.tingcheyouhui = tingcheyouhui;
	}
	
	/**
	 * 获取：停车优惠
	 */
	public String getTingcheyouhui() {
		return tingcheyouhui;
	}
			
}
